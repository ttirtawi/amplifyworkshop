import json
import boto3
from botocore.exceptions import ClientError
import pandas as pd
import numpy as np
import xlsxwriter
import logging
import datetime
client = boto3.client('dynamodb')
s3 = boto3.client('s3')

def createReport(requestBody,tableName,s3Bucket):
    print(requestBody)
    USERNAME = requestBody['username']
    TABLE_NAME = tableName;
    START_REPORT = requestBody["start_report"]
    END_REPORT = requestBody["end_report"]
    FILE_NAME = USERNAME + '-' + START_REPORT + '-' + END_REPORT + '.xlsx'
    FILE_NAME = USERNAME + '-' + datetime.datetime.strptime(START_REPORT, "%Y-%m-%dT%H:%M:%S.%fZ").strftime("%Y-%m-%d") + '-' + datetime.datetime.strptime(END_REPORT, "%Y-%m-%dT%H:%M:%S.%fZ").strftime("%Y-%m-%d") + '.xlsx'
    FILE_OUTPUT = '/tmp/'+ FILE_NAME
    
    print("username: ", USERNAME)
    print("start_report:", START_REPORT)
    print("end_report:", END_REPORT)
    print("table_name:", TABLE_NAME)
    # query GROCERYBUDGET

    response = client.query(
        TableName=TABLE_NAME,
        ExpressionAttributeValues={
            ':v1': {
                'S': 'USER#'+USERNAME
            },
            ':v2': {
                'S': 'GROCERYBUDGET#'
            },
            ':filter1': {
                'S': START_REPORT
            },
            ':filter2': {
                'S': END_REPORT
            },
        },
        KeyConditionExpression='PK = :v1 AND begins_with ( SK, :v2 )',
        FilterExpression='(grocery_date >= :filter1 and grocery_date<= :filter2)',
        ScanIndexForward=False, 
    )

    print("response GROCERYBUDGET: ", response)
    data = []
    for item in response["Items"]:
        temp = {}
        temp["username"] = item["username"]["S"];
        temp["grocery_id"] = item["grocery_id"]["S"];
        temp["grocery_date"] =datetime.datetime.strptime(item["grocery_date"]["S"],"%Y-%m-%dT%H:%M:%S.%fZ").strftime('%d %B %Y')
        temp["grocery_name"] = "GROCERY BUDGET";
        temp["grocery_qty"] = 1;
        temp["debit"] = int(item["grocery_budget"]["S"]);
        temp["kredit"] = 0;
        data.append(temp)

    # query Grocery Items
    response = client.query(
        TableName=TABLE_NAME,
        ExpressionAttributeValues={
            ':v1': {
                'S': 'USER#'+USERNAME
            },
            ':v2': {
                'S': 'GROCERYITEM#'
            },
            ':filter1': {
                'S': START_REPORT
            },
            ':filter2': {
                'S': END_REPORT
            },
        },
        KeyConditionExpression='PK = :v1 AND begins_with ( SK, :v2 )',
        FilterExpression='(grocery_date >= :filter1 and grocery_date<= :filter2)',
        ScanIndexForward=False, 
    )
    print("response grocery item: ", response)

    for item in response["Items"]:
        temp = {}
        temp["username"] = item["username"]["S"];
        temp["grocery_id"] = item["grocery_id"]["S"];
        temp["grocery_date"] = datetime.datetime.strptime(item["grocery_date"]["S"],"%Y-%m-%dT%H:%M:%S.%fZ").strftime('%d %B %Y')
        temp["grocery_name"] = item["grocery_name"]["S"];
        temp["grocery_qty"] = int(item["grocery_qty"]["S"]);
        temp["kredit"] = int(item["grocery_cost"]["S"]);
        temp["debit"] = 0;
        data.append(temp)

    print('data:', data)
    print('data length', len(data))

    if len(data) > 0:
        dataPd = pd.DataFrame(data)
        dataPd.index += 1
        print(dataPd)
        # rename column header
        dataPd.columns = ['User','ID', 'Date', 'Item', 'Quantity', 'Debit', 'Kredit' ]

        # filter only required column
        newCols = ['User', 'Date', 'Item', 'Quantity', 'Debit', 'Kredit' ]
        newDataPd = dataPd[newCols]

        pd.options.mode.chained_assignment = None  # default='warn'
        newDataPd.loc['Total']= newDataPd.sum(numeric_only=True, axis=0)

        print(newDataPd)

        writer = pd.ExcelWriter(FILE_OUTPUT, engine='xlsxwriter')
        newDataPd.to_excel(writer, sheet_name='Sheet1')
        workbook  = writer.book
        worksheet = writer.sheets['Sheet1']
        currency_format = workbook.add_format()
        currency_format.set_border(style=1)
        currency_format.set_num_format('#,##0')

        format = workbook.add_format()
        format.set_border(style=1)
        format.set_fg_color('white')

        # Set the column width and format.
        worksheet.set_zoom(140)

        worksheet.set_column('A:A', 10, format)
        worksheet.set_column('B:B', 25, format)
        worksheet.set_column('C:C', 20, format)
        worksheet.set_column('D:D', 30, format)
        worksheet.set_column('E:E', 12, format)
        worksheet.set_column('F:G', 15, currency_format)

        # Close the Pandas Excel writer and output the Excel file.
        writer.save()

        # Upload to S3
        s3.upload_file(FILE_OUTPUT, s3Bucket, FILE_NAME )
        # Generate presigned URL

        try:
            s3url = s3.generate_presigned_url('get_object',
                                                    Params={'Bucket': s3Bucket,
                                                            'Key': FILE_NAME},
                                                    ExpiresIn=3600)
            responseCode = 200;
        except ClientError as e:
            logging.error(e)
            responseCode = 500
            s3url = ''
            return None
    else:
        s3url = ''
        responseCode = 404

    # return response
    body = {
        "url": s3url
    }
    response = {
        "statusCode": responseCode,
        "body": json.dumps(body),
        "headers": {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Credentials': 'true',
        }
    }
    return response    