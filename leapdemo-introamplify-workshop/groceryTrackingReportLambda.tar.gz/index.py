import json
import os
from createReport import createReport
  
tableName = os.environ['STORAGE_GROCERYTABLE_NAME']
s3Bucket = os.environ['STORAGE_GROCERYBUCKET_BUCKETNAME']
def handler(event, context):
  print('received event:')
  print(event)
  response = ''

  if (event["httpMethod"] == 'GET')  :
    message = 'This is GET function'
  elif (event["httpMethod"] == 'POST'):
    message = 'This is POST function'
    requestBody = json.loads(event["body"])
    response = createReport(requestBody,tableName,s3Bucket)
  elif (event["httpMethod"] == 'PUT'):
    message = 'This is PUT function'
  elif (event["httpMethod"] == 'DELETE'):
    message = 'This is DELETE function'

  return response
